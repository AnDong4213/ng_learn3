export const environment = {
  production: true,
  baseUrl: 'http://apis.imooc.com/api',
  icode: 'B1F546D62BED16DA',
};
