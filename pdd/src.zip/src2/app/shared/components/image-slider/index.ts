import { from } from 'rxjs';

export * from './image-slider.component'