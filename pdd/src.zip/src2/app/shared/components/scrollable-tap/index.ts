export * from './scrollable-tap.component';
