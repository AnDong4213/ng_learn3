export * from './home-detail.component';
