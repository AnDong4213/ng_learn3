export * from './parent.component';
