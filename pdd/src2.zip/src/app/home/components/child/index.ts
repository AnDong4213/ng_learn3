export * from './child.component';
