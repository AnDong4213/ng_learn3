export * from './vertical-grid.component';
